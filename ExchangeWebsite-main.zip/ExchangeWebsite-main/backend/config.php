<?php
{
    define("CURRENT_LOCATION", "http://localhost/exchange.cash/");
    define("MYSQLI_USER", "root");
    define("MYSQLI_PASSWORD", "");
    define("MYSQLI_HOST", "localhost");
    define("MYSQLI_DATABASE", "ECash");
    define("ACCESS_TOKEN_LEN", "32");
    define("ACCESS_TOKEN_EXPIRE", 150);
    define("COOKIE_EXPIRE", 3600);
}
?>